package com.example.smssentinel

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.RingtoneManager

const val KIND_ALERT = 0
const val KIND_ALARM = 1
const val KIND_REMINDER = 2

/** Everything that talks to the user: notifications, the loud alarm, repeating reminders and snooze. */
object Alerts {
    const val CH_ALERT = "alerts"
    const val CH_ALARM = "alarm"
    const val CH_INFO = "info"

    const val ACTION_FIRE = "com.example.smssentinel.FIRE"
    const val ACTION_STOP = "com.example.smssentinel.STOP"
    const val ACTION_DISMISS = "com.example.smssentinel.DISMISS"
    const val ACTION_SNOOZE_REMINDER = "com.example.smssentinel.SNOOZE_REMINDER"
    const val ACTION_SNOOZE_ALARM = "com.example.smssentinel.SNOOZE_ALARM"
    const val ACTION_ALARM_AGAIN = "com.example.smssentinel.ALARM_AGAIN"

    const val EXTRA_RULE = "rule"
    const val EXTRA_MIN = "min"
    const val EXTRA_TEXT = "text"

    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    // PendingIntent request codes are ruleId * 10 + slot, so rules never overwrite each other.
    private const val SLOT_FIRE = 1
    private const val SLOT_OPEN = 2
    private const val SLOT_STOP = 3
    private const val SLOT_DISMISS = 4
    private const val SLOT_SNOOZE_REMINDER = 5
    private const val SLOT_FULLSCREEN = 6
    private const val SLOT_ALARM_AGAIN = 7
    private const val SLOT_SNOOZE_ALARM = 8

    private fun createChannels(nm: NotificationManager) {
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Alerts and reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_INFO, "Forwarding confirmations", NotificationManager.IMPORTANCE_LOW))
        val alarm = NotificationChannel(CH_ALARM, "Loud alarms", NotificationManager.IMPORTANCE_HIGH)
        alarm.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        alarm.enableVibration(true)
        alarm.vibrationPattern = longArrayOf(0, 600, 400, 600, 400, 600)
        nm.createNotificationChannel(alarm)
    }

    private fun ruleIntent(ctx: Context, action: String, id: Int, minutes: Int = 0): Intent =
        Intent(ctx, ReminderReceiver::class.java).setAction(action)
            .putExtra(EXTRA_RULE, id).putExtra(EXTRA_MIN, minutes)

    private fun receiverPi(ctx: Context, action: String, id: Int, slot: Int, minutes: Int = 0): PendingIntent =
        PendingIntent.getBroadcast(ctx, id * 10 + slot, ruleIntent(ctx, action, id, minutes), FLAGS)

    private fun openAppPi(ctx: Context, id: Int): PendingIntent =
        PendingIntent.getActivity(ctx, id * 10 + SLOT_OPEN, Intent(ctx, MainActivity::class.java), FLAGS)

    private fun action(ctx: Context, label: String, pi: PendingIntent): Notification.Action =
        Notification.Action.Builder(
            Icon.createWithResource(ctx, R.drawable.ic_close), label, pi
        ).build()

    fun savedText(ctx: Context, id: Int): String = RuleStore.prefs(ctx).getString("alerttext_$id", "") ?: ""

    /**
     * Posts a notification for a rule. Returns false if it was suppressed (outside the rule's time window).
     * [force] ignores the time window (test button, snoozed alarms).
     */
    fun post(ctx: Context, r: Rule, text: String, kind: Int, force: Boolean = false): Boolean {
        if (!force && !Matcher.inWindow(r)) return false
        val nm = ctx.service<NotificationManager>()
        createChannels(nm)
        RuleStore.prefs(ctx).edit().putString("alerttext_${r.id}", text).apply()

        val alarm = kind == KIND_ALARM
        val title = if (kind == KIND_REMINDER) "Reminder: ${r.name}" else r.name
        val b = Notification.Builder(ctx, if (alarm) CH_ALARM else CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_guardly)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openAppPi(ctx, r.id))
            .setAutoCancel(!alarm)

        if (alarm) {
            val fs = PendingIntent.getActivity(
                ctx, r.id * 10 + SLOT_FULLSCREEN,
                Intent(ctx, AlarmActivity::class.java)
                    .putExtra(EXTRA_RULE, r.id).putExtra(EXTRA_TEXT, text)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                FLAGS
            )
            b.setCategory(Notification.CATEGORY_ALARM)
            b.setTimeoutAfter(10 * 60 * 1000L)  // stop ringing after 10 minutes
            b.setFullScreenIntent(fs, true)
            b.addAction(action(ctx, "Snooze 10 min", receiverPi(ctx, ACTION_SNOOZE_ALARM, r.id, SLOT_SNOOZE_ALARM, 10)))
            b.addAction(action(ctx, "Dismiss", receiverPi(ctx, ACTION_DISMISS, r.id, SLOT_DISMISS)))
        } else if (r.remind && isReminding(ctx, r.id)) {
            b.addAction(action(ctx, "Mark as done", receiverPi(ctx, ACTION_STOP, r.id, SLOT_STOP)))
            b.addAction(action(ctx, "Snooze 1 hour", receiverPi(ctx, ACTION_SNOOZE_REMINDER, r.id, SLOT_SNOOZE_REMINDER, 60)))
        } else {
            b.addAction(action(ctx, "Dismiss", receiverPi(ctx, ACTION_DISMISS, r.id, SLOT_DISMISS)))
        }

        val n = b.build()
        if (alarm) n.flags = n.flags or Notification.FLAG_INSISTENT  // sound repeats until silenced
        nm.notify(r.id, n)
        return true
    }

    /** Low-priority confirmation that an SMS was forwarded (can be switched off in Settings). */
    fun notifyForwarded(ctx: Context, ruleId: Int, ruleName: String, to: String) {
        if (!RuleStore.confirmForward(ctx)) return
        val nm = ctx.service<NotificationManager>()
        createChannels(nm)
        val n = Notification.Builder(ctx, CH_INFO)
            .setSmallIcon(R.drawable.ic_stat_guardly)
            .setContentTitle("SMS forwarded")
            .setContentText("Sent to $to  -  $ruleName")
            .setContentIntent(openAppPi(ctx, ruleId))
            .setAutoCancel(true)
            .build()
        nm.notify(100000 + (System.currentTimeMillis() % 100000).toInt(), n)
    }

    /** Always shown (not optional): a forward that did not go out must not pass unnoticed. */
    fun notifyForwardFailed(ctx: Context, ruleId: Int, ruleName: String, to: String, reason: String) {
        val nm = ctx.service<NotificationManager>()
        createChannels(nm)
        val text = "$ruleName  ->  $to: $reason"
        val n = Notification.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_guardly)
            .setContentTitle("SMS could not be forwarded")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openAppPi(ctx, ruleId))
            .setAutoCancel(true)
            .build()
        nm.notify(200000 + (System.currentTimeMillis() % 100000).toInt(), n)
    }

    fun dismiss(ctx: Context, id: Int) {
        ctx.service<NotificationManager>().cancel(id)
    }

    /** Test button: shows how the rule will alert, without needing a real SMS. */
    fun test(ctx: Context, r: Rule) {
        val rule = if (r.id == 0) r.copy(id = 9999) else r
        val kind = if (rule.alarm) KIND_ALARM else KIND_ALERT
        post(ctx, rule, "Test alert: this is how the rule will notify you.", kind, true)
    }

    // ---------------------------------------------------------------- repeating reminders

    fun isReminding(ctx: Context, id: Int) = RuleStore.prefs(ctx).getBoolean("rem_$id", false)

    fun startReminder(ctx: Context, r: Rule) {
        if (isReminding(ctx, r.id)) return
        RuleStore.prefs(ctx).edit().putBoolean("rem_${r.id}", true).apply()
        scheduleNext(ctx, r, r.intervalMin)
    }

    fun stopReminder(ctx: Context, id: Int, why: String) {
        val was = isReminding(ctx, id)
        RuleStore.prefs(ctx).edit().putBoolean("rem_$id", false).apply()
        ctx.service<AlarmManager>().cancel(firePi(ctx, id))
        dismiss(ctx, id)
        if (was) EventLog.add(ctx, EV_SYSTEM, "Reminders stopped", why)
    }

    private fun firePi(ctx: Context, id: Int): PendingIntent = receiverPi(ctx, ACTION_FIRE, id, SLOT_FIRE)

    /**
     * Schedules the next reminder. Inexact alarm: Android batches it with other wake-ups (battery friendly).
     * If it would land outside the rule's allowed time window, it waits until the window opens.
     */
    fun scheduleNext(ctx: Context, r: Rule, minutes: Int) {
        val am = ctx.service<AlarmManager>()
        var at = System.currentTimeMillis() + maxOf(1, minutes) * 60_000L
        at = Matcher.nextAllowed(r, at)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, firePi(ctx, r.id))
    }

    fun snoozeReminder(ctx: Context, r: Rule, minutes: Int) {
        if (!isReminding(ctx, r.id)) return
        dismiss(ctx, r.id)
        scheduleNext(ctx, r, minutes)
    }

    // ---------------------------------------------------------------- alarm snooze

    /** Silences the alarm now and rings again after [minutes]. Uses an alarm-clock alarm so it is on time. */
    fun snoozeAlarm(ctx: Context, r: Rule, minutes: Int) {
        dismiss(ctx, r.id)
        val am = ctx.service<AlarmManager>()
        val at = System.currentTimeMillis() + minutes * 60_000L
        val again = receiverPi(ctx, ACTION_ALARM_AGAIN, r.id, SLOT_ALARM_AGAIN)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, openAppPi(ctx, r.id)), again)
        EventLog.add(ctx, EV_SYSTEM, "Alarm snoozed", "${r.name}: rings again in $minutes min")
    }
}
