package com.example.smssentinel

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.LinearLayout
import android.window.OnBackInvokedDispatcher

/** Record taps, replay them, and say what to do when a step cannot be found. */
class MacrosActivity : Activity() {
    private lateinit var body: LinearLayout
    private var editing: Macro? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = column(this)
        root.setBackgroundColor(BG)
        body = column(this)
        root.addView(scrolled(this, body), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        applyInsets(root)
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) { goBack() }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        goBack()
    }

    private fun goBack() {
        val e = editing
        if (e != null) {
            MacroStore.upsert(this, e)
            editing = null
            render()
        } else finish()
    }

    private fun render() {
        body.removeAllViews()
        body.setPadding(dp(12), dp(10), dp(20), dp(28))
        val e = editing
        if (e == null) list() else editor(e)
    }

    private fun header(title: String, sub: String) {
        val h = row(this)
        h.addView(iconButton(this, R.drawable.ic_back) { goBack() })
        val col = column(this)
        col.addView(text(this, title, 22f, INK, true))
        if (sub.isNotEmpty()) col.addView(text(this, sub, 13f, MUTED))
        h.putH(col, 1f, 4)
        body.addView(h)
    }

    // ---------------------------------------------------------------- list

    private fun list() {
        header("Macros", "Record taps and replay them")
        val inner = column(this)
        inner.setPadding(dp(8), 0, 0, 0)
        body.addView(inner)

        inner.put(
            note(
                this,
                "Press Record, tap through the steps in any app, then press Stop in the notification. Guardly remembers which buttons you tapped. " +
                    "What you type and password fields are never stored; typing becomes a Type text step you can edit, e.g. {sms}. A macro can run from a rule (Rules > Automate with a macro) or from here. " +
                    "It only runs while the phone is unlocked, and it stops by itself after 2 minutes."
            ),
            top = 14, bottom = 12
        )
        inner.put(button(this, "Record a new macro", Btn.PRIMARY) { askName() }, bottom = 8)

        val all = MacroStore.load(this)
        if (all.isEmpty()) {
            inner.put(text(this, "No macros yet.", 14f, MUTED), top = 12)
        }
        for (m in all) {
            val c = card(this)
            c.addView(text(this, m.name, 16f, INK, true))
            c.addView(text(this, "${m.steps.size} steps, starts in ${m.steps.firstOrNull()?.pkg ?: "-"}", 13f, MUTED))
            val actions = row(this)
            actions.putH(pill(this, "Run now", OK) { runNow(m) })
            actions.putH(pill(this, "Edit", ACCENT) { editing = m; render() }, 0f, 8)
            actions.putH(pill(this, "Delete", BAD) {
                confirm(this, "Delete macro?", "\"${m.name}\" will be removed. Rules that use it will stop running it.", "Delete") {
                    MacroStore.delete(this, m.id)
                    for (r in RuleStore.load(this)) if (r.macroId == m.id) { r.macroId = 0; RuleStore.upsert(this, r) }
                    render()
                }
            }, 0f, 8)
            c.put(actions, top = 10)
            inner.put(c, top = 12)
        }
    }

    private fun askName() {
        if (!PhoneControl.serviceEnabled(this)) {
            toast(this, "Turn on Phone control in Settings first.")
            return
        }
        val box = input(this, "Name, e.g. Open bank app", "", InputType.TYPE_CLASS_TEXT) { }
        val pad = column(this)
        pad.setPadding(dp(20), dp(8), dp(20), 0)
        pad.addView(box)
        AlertDialog.Builder(this)
            .setTitle("Name this macro")
            .setView(pad)
            .setPositiveButton("Start recording") { _, _ ->
                val why = PhoneControl.startRecording(this, box.text.toString().trim())
                if (why != null) {
                    toast(this, why)
                } else {
                    toast(this, "Recording. Tap through your steps, then press Stop in the notification.")
                    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun runNow(m: Macro) {
        val why = PhoneControl.runMacro(this, m.id, "Manual run")
        if (why != null) toast(this, why) else toast(this, "Running ${m.name}...")
    }

    // ---------------------------------------------------------------- editor

    private fun editor(m: Macro) {
        header("Edit macro", "${m.steps.size} steps")
        val inner = column(this)
        inner.setPadding(dp(8), 0, 0, 0)
        body.addView(inner)
        inner.put(fieldLabel(this, "Name"), top = 14)
        inner.put(input(this, "Macro name", m.name) { m.name = it.ifBlank { "Macro" } })
        inner.put(
            note(
                this,
                "Steps run from top to bottom. In a Type text step you can use {sms} (the SMS text), {sender} and {rule}. Changes save when you go back."
            ),
            top = 6, bottom = 4
        )

        m.steps.forEachIndexed { i, s ->
            val c = card(this)
            c.addView(text(this, "${i + 1}. ${s.title()}", 15f, INK, true))
            if (s.pkg.isNotEmpty()) c.addView(text(this, s.pkg, 12f, MUTED))
            when (s.kind) {
                K_TAP -> {
                    c.put(fieldLabel(this, "If not found"), top = 8)
                    val altBox = column(this)
                    fun showAlt() {
                        altBox.visibility = if (s.ifMissing == IF_ALT) View.VISIBLE else View.GONE
                    }
                    c.put(choiceRow(this, listOf("Stop", "Skip it", "Tap first similar", "Tap same spot", "Tap other text"), s.ifMissing) {
                        s.ifMissing = it
                        showAlt()
                    })
                    altBox.put(input(this, "Text to tap instead", s.alt) { s.alt = it }, top = 8)
                    c.put(altBox)
                    showAlt()
                    c.put(waitRow(s, "Wait up to"), top = 10)
                }
                K_TYPE -> {
                    c.put(fieldLabel(this, "Text to type"), top = 8)
                    c.put(input(this, "e.g. {sms}", s.text, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE) { s.text = it })
                    c.put(fieldLabel(this, "If the text field is not found"), top = 8)
                    c.put(choiceRow(this, listOf("Stop", "Skip it"), s.ifMissing.coerceAtMost(1)) { s.ifMissing = it })
                    c.put(waitRow(s, "Wait up to"), top = 10)
                }
                K_WAIT -> c.put(waitRow(s, "Pause for"), top = 8)
                else -> {}
            }
            val ctl = row(this)
            ctl.putH(View(this), 1f)
            if (i > 0) ctl.putH(pill(this, "Up", MUTED) { m.steps.add(i - 1, m.steps.removeAt(i)); render() }, 0f, 8)
            if (i < m.steps.size - 1) ctl.putH(pill(this, "Down", MUTED) { m.steps.add(i + 1, m.steps.removeAt(i)); render() }, 0f, 8)
            ctl.putH(pill(this, "Remove", BAD) { m.steps.removeAt(i); render() }, 0f, 8)
            c.put(ctl, top = 10)
            inner.put(c, top = 12)
        }

        inner.put(sectionHeader(this, "Add a step"))
        val add1 = row(this)
        add1.putH(pill(this, "Type text", ACCENT) { addStep(m, Step("", "", "{sms}", "", "", 0, 0, kind = K_TYPE)) })
        add1.putH(pill(this, "Wait", ACCENT) { addStep(m, Step("", "", "", "", "", 0, 0, waitSec = 3, kind = K_WAIT)) }, 0f, 8)
        add1.putH(pill(this, "Open app", ACCENT) { pickApp(m) }, 0f, 8)
        inner.put(add1)
        val add2 = row(this)
        add2.putH(pill(this, "Back", ACCENT) { addStep(m, Step("", "", "", "", "", 0, 0, kind = K_BACK)) })
        add2.putH(pill(this, "Home", ACCENT) { addStep(m, Step("", "", "", "", "", 0, 0, kind = K_HOME)) }, 0f, 8)
        add2.putH(pill(this, "Scroll", ACCENT) { addStep(m, Step("", "", "", "", "", 0, 0, kind = K_SCROLL)) }, 0f, 8)
        inner.put(add2, top = 8)
        inner.put(note(this, "To add taps, record a new macro. Typing in a text field while recording adds a Type text step automatically."), top = 8)
    }

    private fun waitRow(s: Step, label: String): LinearLayout {
        val r = row(this)
        val t = text(this, "$label ${s.waitSec}s", 12f, MUTED)
        r.putH(t, 1f)
        r.putH(pill(this, "-", MUTED) { s.waitSec = (s.waitSec - 1).coerceAtLeast(1); t.text = "$label ${s.waitSec}s" }, 0f, 8)
        r.putH(pill(this, "+", MUTED) { s.waitSec = (s.waitSec + 1).coerceAtMost(60); t.text = "$label ${s.waitSec}s" }, 0f, 8)
        return r
    }

    private fun addStep(m: Macro, s: Step) {
        if (m.steps.size >= MacroStore.MAX_STEPS) {
            toast(this, "A macro can have up to ${MacroStore.MAX_STEPS} steps.")
            return
        }
        m.steps.add(s)
        render()
    }

    private fun pickApp(m: Macro) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        if (apps.isEmpty()) {
            toast(this, "No apps found.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Open which app?")
            .setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                addStep(m, Step(apps[i].first, "", apps[i].second, "", "", 0, 0, kind = K_OPEN))
            }
            .show()
    }
}
