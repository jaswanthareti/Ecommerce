package com.example.smssentinel

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager

/**
 * Android calls this when the phone has really sent a forwarded SMS (or failed to).
 * Success is logged as "SMS forwarded"; failure is logged and shown as a notification.
 */
class SentReceiver : BroadcastReceiver() {
    companion object {
        const val EXTRA_RULE_ID = "ruleId"
        const val EXTRA_RULE_NAME = "ruleName"
        const val EXTRA_TO = "to"
        const val EXTRA_FROM = "from"
        const val EXTRA_PART = "part"
        const val EXTRA_TOTAL = "total"

        fun reason(code: Int): String = when (code) {
            SmsManager.RESULT_ERROR_GENERIC_FAILURE -> "The phone could not send it. Check your balance and signal."
            SmsManager.RESULT_ERROR_RADIO_OFF -> "Airplane mode or the radio is off."
            SmsManager.RESULT_ERROR_NULL_PDU -> "The message was empty or invalid."
            SmsManager.RESULT_ERROR_NO_SERVICE -> "No network signal."
            else -> "Error code $code."
        }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra(EXTRA_RULE_ID, 0)
        val name = intent.getStringExtra(EXTRA_RULE_NAME) ?: "Rule"
        val to = intent.getStringExtra(EXTRA_TO) ?: ""
        val from = intent.getStringExtra(EXTRA_FROM) ?: ""
        val part = intent.getIntExtra(EXTRA_PART, 0)
        val total = intent.getIntExtra(EXTRA_TOTAL, 1)

        if (resultCode == Activity.RESULT_OK) {
            // A long SMS is sent in several parts; report once, when the last one has gone.
            if (part == total - 1) {
                EventLog.add(ctx, EV_FORWARDED, "SMS forwarded", "$name: from $from to $to")
                Alerts.notifyForwarded(ctx, id, name, to)
            }
        } else {
            val why = reason(resultCode)
            EventLog.add(ctx, EV_SYSTEM, "Forward failed", "$name: to $to. $why")
            Alerts.notifyForwardFailed(ctx, id, name, to, why)
        }
    }
}
