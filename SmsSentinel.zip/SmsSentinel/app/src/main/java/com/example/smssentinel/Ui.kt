package com.example.smssentinel

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- palette (dark)
val BG: Int = Color.parseColor("#0B1220")
val CARD: Int = Color.parseColor("#121B2E")
val INK: Int = Color.parseColor("#F1F5F9")
val MUTED: Int = Color.parseColor("#94A3B8")
val LINE: Int = Color.parseColor("#223048")
val ACCENT: Int = Color.parseColor("#38BDF8")
val PRIMARY_A: Int = Color.parseColor("#0284C7")
val PRIMARY_B: Int = Color.parseColor("#7C3AED")
val OK: Int = Color.parseColor("#22C55E")
val WARN: Int = Color.parseColor("#F59E0B")
val BAD: Int = Color.parseColor("#EF4444")
val PURPLE: Int = Color.parseColor("#A78BFA")
val TEAL: Int = Color.parseColor("#2DD4BF")

/** A translucent version of a colour, for soft backgrounds. */
fun tint(c: Int, a: Float = 0.18f): Int = Color.argb((a * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

enum class Btn { PRIMARY, SECONDARY, DANGER, GHOST }

// ---------------------------------------------------------------- basics
inline fun <reified T : Any> Context.service(): T = getSystemService(T::class.java) as T

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun rounded(ctx: Context, color: Int, radiusDp: Int, strokeColor: Int? = null): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        setCornerRadius(ctx.dp(radiusDp).toFloat())
        if (strokeColor != null) setStroke(ctx.dp(1), strokeColor)
    }

fun gradient(ctx: Context, a: Int, b: Int, radiusDp: Int): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(a, b)).apply {
        setCornerRadius(ctx.dp(radiusDp).toFloat())
    }

/** Keeps content clear of the status bar, navigation bar and keyboard (edge-to-edge on Android 15+). */
fun applyInsets(root: View) {
    root.setOnApplyWindowInsetsListener { v, insets ->
        if (Build.VERSION.SDK_INT >= 30) {
            val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(i.left, i.top, i.right, i.bottom)
        } else {
            @Suppress("DEPRECATION")
            v.setPadding(
                insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                insets.systemWindowInsetRight, insets.systemWindowInsetBottom
            )
        }
        insets
    }
}

/** Adds a child to a vertical LinearLayout, full width, with top/bottom margins in dp. */
fun LinearLayout.put(v: View, top: Int = 0, bottom: Int = 0) {
    addView(
        v,
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = context.dp(top)
            bottomMargin = context.dp(bottom)
        }
    )
}

/** Adds a child to a horizontal row: weight 0 (wrap) or >0 (share space), with a left margin in dp. */
fun LinearLayout.putH(v: View, weight: Float = 0f, left: Int = 0) {
    val own = v.layoutParams as? LinearLayout.LayoutParams
    // Views that already have a fixed size (icon tiles, round buttons) keep it.
    if (own != null && weight == 0f && own.width > 0 && own.height > 0) {
        own.leftMargin = context.dp(left)
        addView(v, own)
        return
    }
    addView(
        v,
        LinearLayout.LayoutParams(
            if (weight > 0f) 0 else LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            weight
        ).apply { leftMargin = context.dp(left) }
    )
}

fun row(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun column(ctx: Context): LinearLayout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

// ---------------------------------------------------------------- text and containers
fun card(ctx: Context, fill: Int = CARD, stroke: Int? = LINE): LinearLayout = LinearLayout(ctx).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(ctx, fill, 18, stroke)
    setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(16))
}

fun text(ctx: Context, s: String, size: Float = 15f, color: Int = INK, bold: Boolean = false): TextView =
    TextView(ctx).apply {
        setText(s)
        setTextSize(size)
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun heading(ctx: Context, s: String): TextView =
    text(ctx, s, 18f, INK, true).apply { setPadding(ctx.dp(2), ctx.dp(22), 0, ctx.dp(8)) }

fun chip(ctx: Context, s: String, fg: Int): TextView =
    text(ctx, s, 12f, fg, true).apply {
        background = rounded(ctx, tint(fg), 8)
        setPadding(ctx.dp(8), ctx.dp(3), ctx.dp(8), ctx.dp(3))
    }

/** Horizontally scrollable row of small coloured chips. */
fun chipRow(ctx: Context, items: List<Pair<String, Int>>): HorizontalScrollView {
    val r = row(ctx)
    items.forEach { (label, color) ->
        r.addView(chip(ctx, label, color))
        spacer(ctx, r)
    }
    return HorizontalScrollView(ctx).apply {
        setHorizontalScrollBarEnabled(false)
        addView(r)
    }
}

private fun spacer(ctx: Context, r: LinearLayout) {
    r.addView(View(ctx), LinearLayout.LayoutParams(ctx.dp(6), 1))
}

/** Selectable filter chips (All / Forwarding / ...). */
fun filterChips(ctx: Context, labels: List<String>, selected: Int, onSelect: (Int) -> Unit): HorizontalScrollView {
    val r = row(ctx)
    labels.forEachIndexed { i, label ->
        val on = i == selected
        val c = text(ctx, label, 13f, if (on) ACCENT else MUTED, on).apply {
            background = rounded(ctx, if (on) tint(ACCENT, 0.2f) else CARD, 18, if (on) ACCENT else LINE)
            setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
            setOnClickListener { onSelect(i) }
        }
        r.putH(c, 0f, if (i == 0) 0 else 8)
    }
    return HorizontalScrollView(ctx).apply {
        setHorizontalScrollBarEnabled(false)
        addView(r)
    }
}

fun dot(ctx: Context, color: Int): View = View(ctx).apply {
    background = GradientDrawable().apply {
        setShape(GradientDrawable.OVAL)
        setColor(color)
    }
    layoutParams = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8)).apply {
        gravity = Gravity.CENTER_VERTICAL
        rightMargin = ctx.dp(6)
    }
}

// ---------------------------------------------------------------- icons and images
fun iconView(ctx: Context, res: Int, sizeDp: Int = 24, color: Int = INK): ImageView = ImageView(ctx).apply {
    setImageResource(res)
    setColorFilter(color, PorterDuff.Mode.SRC_IN)
    layoutParams = LinearLayout.LayoutParams(ctx.dp(sizeDp), ctx.dp(sizeDp))
}

/** Rounded square with a tinted icon, used on rule cards, settings rows and activity rows. */
fun iconTile(ctx: Context, res: Int, color: Int, sizeDp: Int = 44, iconDp: Int = 22): LinearLayout =
    LinearLayout(ctx).apply {
        gravity = Gravity.CENTER
        background = rounded(ctx, tint(color, 0.18f), 12)
        layoutParams = LinearLayout.LayoutParams(ctx.dp(sizeDp), ctx.dp(sizeDp))
        addView(iconView(ctx, res, iconDp, color))
    }

/** Gradient logo tile with the shield icon. */
fun logoTile(ctx: Context, sizeDp: Int = 44): LinearLayout =
    LinearLayout(ctx).apply {
        gravity = Gravity.CENTER
        background = gradient(ctx, PRIMARY_A, PRIMARY_B, 12)
        layoutParams = LinearLayout.LayoutParams(ctx.dp(sizeDp), ctx.dp(sizeDp))
        addView(iconView(ctx, R.drawable.ic_shield, sizeDp / 2, Color.WHITE))
    }

/** An illustration cropped to a rounded rectangle. */
fun roundedImage(ctx: Context, res: Int, radiusDp: Int = 18): ImageView = ImageView(ctx).apply {
    setImageResource(res)
    scaleType = ImageView.ScaleType.CENTER_CROP
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, ctx.dp(radiusDp).toFloat())
        }
    }
    clipToOutline = true
}

// ---------------------------------------------------------------- buttons
fun button(ctx: Context, label: String, style: Btn = Btn.SECONDARY, onClick: () -> Unit): Button =
    Button(ctx).apply {
        text = label
        setAllCaps(false)
        setTextSize(15f)
        setTypeface(typeface, Typeface.BOLD)
        setMinimumHeight(ctx.dp(48))
        setPadding(ctx.dp(16), 0, ctx.dp(16), 0)
        when (style) {
            Btn.PRIMARY -> {
                background = gradient(ctx, PRIMARY_A, PRIMARY_B, 14)
                setTextColor(Color.WHITE)
            }
            Btn.SECONDARY -> {
                background = rounded(ctx, tint(ACCENT, 0.16f), 14)
                setTextColor(ACCENT)
            }
            Btn.DANGER -> {
                background = rounded(ctx, tint(BAD, 0.16f), 14)
                setTextColor(BAD)
            }
            Btn.GHOST -> {
                background = rounded(ctx, Color.TRANSPARENT, 14, LINE)
                setTextColor(INK)
            }
        }
        setOnClickListener { onClick() }
    }

// ---------------------------------------------------------------- date / time text
private fun sameDay(a: Calendar, b: Calendar) =
    a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

fun clock(ms: Long): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(ms))

/** "Today, 14 Oct 2026" / "Yesterday, 13 Oct 2026" / "5 Oct 2026". */
fun dayLabel(ms: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    val date = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(ms))
    val today = Calendar.getInstance()
    val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    return when {
        sameDay(today, c) -> "Today, $date"
        sameDay(yesterday, c) -> "Yesterday, $date"
        else -> date
    }
}

/** "Today, 11:42 AM" / "Yesterday, 6:21 PM" / "5 Oct, 8:00 AM". */
fun whenLabel(ms: Long): String {
    if (ms == 0L) return "Never triggered"
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    val today = Calendar.getInstance()
    val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    val day = when {
        sameDay(today, c) -> "Today"
        sameDay(yesterday, c) -> "Yesterday"
        else -> SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(ms))
    }
    return "$day, ${clock(ms)}"
}

fun relative(ms: Long): String {
    val mins = (System.currentTimeMillis() - ms) / 60_000L
    return when {
        mins < 1 -> "Just now"
        mins < 60 -> "$mins min ago"
        mins < 24 * 60 -> if (mins < 120) "1 hour ago" else "${mins / 60} hours ago"
        else -> whenLabel(ms)
    }
}

/** Minutes after midnight as "7:00 AM". */
fun fmtMin(min: Int): String {
    val c = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, min / 60)
        set(Calendar.MINUTE, min % 60)
    }
    return SimpleDateFormat("h:mm a", Locale.getDefault()).format(c.time)
}
