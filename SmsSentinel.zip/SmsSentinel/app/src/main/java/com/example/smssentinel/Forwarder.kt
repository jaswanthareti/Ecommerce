package com.example.smssentinel

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.PhoneNumberUtils
import android.telephony.SmsManager

/**
 * Sends the forwarded copy of an SMS. Channels: the WhatsApp app (VIA_APP) or plain SMS. If the app cannot send and the rule allows it, a normal SMS is sent instead.
 * Call from a background thread.
 */
object Forwarder {

    fun forward(ctx: Context, r: Rule, sender: String, body: String) {
        val to = r.forwardTo.trim()
        if (to.isEmpty()) {
            EventLog.add(ctx, EV_SYSTEM, r.name, "Not forwarded: no number set")
            return
        }
        if (PhoneNumberUtils.compare(ctx, to, sender)) return  // never forward back to the sender
        val prefix = r.prefix.trim()
        val text = if (prefix.isEmpty()) body.trim() else "$prefix ${body.trim()}"
        deliver(ctx, r, sender, to, text, r.forwardVia)
    }

    fun deliver(ctx: Context, r: Rule, sender: String, to: String, text: String, via: Int) {
        when (via) {
            VIA_APP -> {
                val why = PhoneControl.submit(ctx, r, sender, to, text)
                if (why == null) {
                    // The service finishes the job later and calls onAppResult().
                    EventLog.add(ctx, EV_SYSTEM, r.name, "Sending through the WhatsApp app...")
                } else {
                    failed(ctx, r, sender, to, text, VIA_APP, why)
                }
            }
            else -> sendSms(ctx, r, sender, to, text)
        }
    }

    /** Result of a job run by the Phone control service. */
    fun onAppResult(ctx: Context, job: PhoneControl.Job, ok: Boolean, why: String) {
        val r = job.rule
        if (ok) {
            EventLog.add(ctx, EV_FORWARDED, "Forwarded via WhatsApp app", "${r.name}: from ${job.sender} to ${job.to}")
            Alerts.notifyForwarded(ctx, r.id, r.name, job.to)
        } else {
            Thread { failed(ctx, r, job.sender, job.to, job.text, VIA_APP, why) }.start()
        }
    }

    fun failed(ctx: Context, r: Rule, sender: String, to: String, text: String, via: Int, why: String) {
        EventLog.add(ctx, EV_SYSTEM, "WhatsApp app failed", "${r.name}: $why")
        if (!r.waFallback) {
            Alerts.notifyForwardFailed(ctx, r.id, r.name, to, why)
            return
        }
        EventLog.add(ctx, EV_SYSTEM, r.name, "Sending a normal SMS instead")
        deliver(ctx, r, sender, to, text, VIA_SMS)
    }

    private fun sendSms(ctx: Context, r: Rule, sender: String, to: String, text: String) {
        try {
            val sms = defaultSmsManager(ctx)
            val parts = sms.divideMessage(text)
            // Android reports back through SentReceiver once the phone has really sent (or failed to send) each part.
            val seq = nextSendNumber(ctx)
            val sent = ArrayList<PendingIntent>()
            for (i in parts.indices) {
                val i2 = Intent(ctx, SentReceiver::class.java)
                    .putExtra(SentReceiver.EXTRA_RULE_ID, r.id)
                    .putExtra(SentReceiver.EXTRA_RULE_NAME, r.name)
                    .putExtra(SentReceiver.EXTRA_TO, to)
                    .putExtra(SentReceiver.EXTRA_FROM, sender)
                    .putExtra(SentReceiver.EXTRA_PART, i)
                    .putExtra(SentReceiver.EXTRA_TOTAL, parts.size)
                sent.add(PendingIntent.getBroadcast(ctx, seq * 16 + minOf(i, 15), i2, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            sms.sendMultipartTextMessage(to, null, parts, sent, null)
        } catch (e: Exception) {
            val why = e.message ?: e.javaClass.simpleName
            EventLog.add(ctx, EV_SYSTEM, "Forward failed", "${r.name}: $why")
            Alerts.notifyForwardFailed(ctx, r.id, r.name, to, why)
        }
    }

    /** A number that is different for every forwarded SMS, so each one gets its own result callback. */
    private fun nextSendNumber(ctx: Context): Int {
        val p = RuleStore.prefs(ctx)
        val n = (p.getInt("sendSeq", 0) + 1) % 100000
        p.edit().putInt("sendSeq", n).apply()
        return n
    }

    @Suppress("DEPRECATION")
    private fun defaultSmsManager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ctx.service<SmsManager>()
        else SmsManager.getDefault()
}
