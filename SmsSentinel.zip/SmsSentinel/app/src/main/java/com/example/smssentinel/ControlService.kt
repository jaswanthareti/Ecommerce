package com.example.smssentinel

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.graphics.Path
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Opens the chat in the normal WhatsApp app with the text filled in, then taps Send.
 * It is declared (res/xml/control_service.xml) to receive events from WhatsApp only, and it does nothing
 * unless Forwarder has queued a job that passed the checks in PhoneControl.submit().
 */
class ControlService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: ControlService? = null
        private const val JOB_TIMEOUT_MS = 15000L
        private const val MAX_QUEUE = 5
        private const val CH_CONTROL = "guardly_control"
        private const val NOTE_ID = 7001
        private const val MACRO_MAX_MS = 120000L
        private const val RECORD_MAX_MS = 180000L
        private val WA = arrayOf("com.whatsapp", "com.whatsapp.w4b")
    }

    private val main = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<PhoneControl.Job>()
    private var current: PhoneControl.Job? = null
    private var timeout: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        EventLog.add(this, EV_SYSTEM, "Phone control", "Service is on")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        main.post {
            current?.let { finish(it, false, "The Phone control service was switched off.") }
            running?.let { endMacro(it, false, "The Phone control service was switched off.") }
            if (recording != null) stopRecording()
            while (queue.isNotEmpty()) Forwarder.onAppResult(this, queue.removeFirst(), false, "The Phone control service was switched off.")
        }
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    // ------------------------------------------------------------------ macros: recording

    private class Run(val macro: Macro, val ruleName: String) {
        var idx = 0
        val started = System.currentTimeMillis()
        var stepStart = started
        var vars: Map<String, String> = emptyMap()
    }

    private var recording: Macro? = null
    private var running: Run? = null
    private val autoStop = Runnable { stopRecording() }
    private val tick = Runnable { stepTick() }

    /**
     * While recording or running a macro the service may look at the app being operated, not only WhatsApp.
     * It goes back to WhatsApp only as soon as that is over.
     */
    private fun widen(on: Boolean) {
        val i = serviceInfo ?: return
        i.packageNames = if (on) null else WA
        i.eventTypes = if (on) {
            AccessibilityEvent.TYPE_VIEW_CLICKED or AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        } else {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        }
        serviceInfo = i
    }

    fun isBusy(): Boolean = recording != null || running != null || current != null

    /** Returns null when recording started, otherwise the reason it did not. */
    fun startRecording(name: String): String? {
        if (isBusy()) return "Guardly is busy with another job."
        recording = Macro(0, name.ifBlank { "Macro" })
        widen(true)
        showRecordingNote(0)
        main.postDelayed(autoStop, RECORD_MAX_MS)
        return null
    }

    fun stopRecording() {
        val m = recording ?: return
        recording = null
        main.removeCallbacks(autoStop)
        widen(false)
        val nm = service<NotificationManager>()
        nm.cancel(NOTE_ID)
        if (m.steps.isEmpty()) {
            EventLog.add(this, EV_SYSTEM, "Recording stopped", "No taps were recorded")
        } else {
            MacroStore.upsert(this, m)
            EventLog.add(this, EV_SYSTEM, "Macro saved", "${m.name}: ${m.steps.size} steps")
            postNote("Macro saved", "${m.name}: ${m.steps.size} steps. Open Guardly > Settings > Macros to edit it.", false)
        }
    }

    private fun channel(): String {
        val nm = service<NotificationManager>()
        if (nm.getNotificationChannel(CH_CONTROL) == null) {
            nm.createNotificationChannel(NotificationChannel(CH_CONTROL, "Phone control", NotificationManager.IMPORTANCE_LOW))
        }
        return CH_CONTROL
    }

    private fun postNote(title: String, text: String, ongoing: Boolean, stopButton: Boolean = false) {
        val b = Notification.Builder(this, channel())
            .setSmallIcon(R.drawable.ic_stat_guardly)
            .setContentTitle(title).setContentText(text)
            .setOngoing(ongoing)
        if (stopButton) {
            val pi = PendingIntent.getBroadcast(
                this, 1, Intent(this, RecordStopReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_close), "Stop recording", pi).build())
        }
        service<NotificationManager>().notify(NOTE_ID, b.build())
    }

    private fun showRecordingNote(n: Int) =
        postNote("Recording taps", if (n == 0) "Tap through the steps now. Press Stop when done." else "$n taps recorded. Press Stop when done.", true, true)

    private fun capture(rec: Macro, event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        if (rec.steps.size >= MacroStore.MAX_STEPS) return
        val n = event.source ?: return
        if (n.isPassword) return
        val b = Rect()
        n.getBoundsInScreen(b)
        val label = if (n.isEditable) "" else (n.text?.toString() ?: event.text.joinToString(" ")).take(80)
        rec.steps.add(
            Step(
                pkg, n.viewIdResourceName ?: "", label, n.contentDescription?.toString()?.take(80) ?: "",
                n.className?.toString() ?: "", b.centerX(), b.centerY()
            )
        )
        showRecordingNote(rec.steps.size)
    }

    /** Typing is recorded as one "Type text" step. What you typed is NOT stored: the step starts as {sms} and you edit it later. */
    private fun captureTyping(rec: Macro, event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        if (rec.steps.size >= MacroStore.MAX_STEPS) return
        val n = event.source ?: return
        if (n.isPassword || !n.isEditable) return
        val id = n.viewIdResourceName ?: ""
        val last = rec.steps.lastOrNull()
        if (last != null && last.kind == K_TYPE && last.pkg == pkg && last.viewId == id) return
        rec.steps.add(Step(pkg, id, "{sms}", "", n.className?.toString() ?: "", 0, 0, kind = K_TYPE))
        showRecordingNote(rec.steps.size)
    }

    // ------------------------------------------------------------------ macros: playback

    /** Call on any thread. Failures are written to the activity log. [vars] fill {sms}, {sender} and {rule} in typed text. */
    fun startMacro(m: Macro, ruleName: String, vars: Map<String, String> = emptyMap()) {
        main.post {
            if (isBusy()) {
                EventLog.add(this, EV_SYSTEM, ruleName, "Macro not run: Guardly is busy with another job.")
                return@post
            }
            val first = m.steps.first()
            var delay = 400L
            var launch: Intent? = null
            if (first.kind != K_OPEN && first.pkg.isNotEmpty()) {
                launch = packageManager.getLaunchIntentForPackage(first.pkg)
                if (launch == null) {
                    EventLog.add(this, EV_SYSTEM, ruleName, "Macro not run: ${first.pkg} is not installed.")
                    return@post
                }
                delay = 1500L
            }
            val run = Run(m, ruleName)
            run.vars = vars
            running = run
            widen(true)
            EventLog.add(this, EV_SYSTEM, "Macro started", "${m.name}: ${m.steps.size} steps")
            if (launch != null) startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            run.stepStart = System.currentTimeMillis() + delay
            main.postDelayed(tick, delay)
        }
    }

    private fun endMacro(run: Run, ok: Boolean, why: String) {
        if (running !== run) return
        running = null
        main.removeCallbacks(tick)
        widen(false)
        // The last screen stays open: the macro does not press Home or close the app.
        EventLog.add(this, EV_SYSTEM, if (ok) "Macro finished" else "Macro stopped", "${run.macro.name}${if (ok) "" else ": $why"}")
        main.postDelayed({ next() }, 800)
    }

    private fun fill(run: Run, t: String): String =
        t.replace("{sms}", run.vars["sms"] ?: "").replace("{sender}", run.vars["sender"] ?: "").replace("{rule}", run.vars["rule"] ?: run.ruleName)

    private fun stepTick() {
        val run = running ?: return
        val now = System.currentTimeMillis()
        if (!PhoneControl.enabled(this)) return endMacro(run, false, "Phone control was switched off.")
        if (service<KeyguardManager>().isKeyguardLocked) return endMacro(run, false, "The phone was locked.")
        if (now - run.started > MACRO_MAX_MS) return endMacro(run, false, "It took longer than ${MACRO_MAX_MS / 1000} seconds.")
        if (run.idx >= run.macro.steps.size) return endMacro(run, true, "")

        val step = run.macro.steps[run.idx]
        val n = run.idx + 1
        when (step.kind) {
            K_WAIT -> {
                if (now - run.stepStart < step.waitSec * 1000L) main.postDelayed(tick, 400) else advance(run)
                return
            }
            K_BACK -> { performGlobalAction(GLOBAL_ACTION_BACK); EventLog.add(this, EV_SYSTEM, "Macro step $n", "Pressed Back"); return advance(run) }
            K_HOME -> { performGlobalAction(GLOBAL_ACTION_HOME); EventLog.add(this, EV_SYSTEM, "Macro step $n", "Pressed Home"); return advance(run) }
            K_OPEN -> {
                val li = packageManager.getLaunchIntentForPackage(step.pkg)
                if (li == null) return endMacro(run, false, "Step $n: ${step.pkg} is not installed.")
                startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                EventLog.add(this, EV_SYSTEM, "Macro step $n", "Opened ${step.text.ifBlank { step.pkg }}")
                run.idx++
                run.stepStart = now + 1500
                main.postDelayed(tick, 1500)
                return
            }
        }

        val root = rootInActiveWindow
        val inApp = root != null && (step.pkg.isEmpty() || root.packageName?.toString() == step.pkg)

        if (step.kind == K_SCROLL) {
            val sc = if (inApp) findIn(root!!) { it.isScrollable } else null
            if (sc != null) {
                sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                EventLog.add(this, EV_SYSTEM, "Macro step $n", "Scrolled")
                return advance(run)
            }
            if (now - run.stepStart < 3000) { main.postDelayed(tick, 400); return }
            EventLog.add(this, EV_SYSTEM, "Macro step $n", "Nothing to scroll, skipped")
            return advance(run)
        }

        if (step.kind == K_TYPE) {
            val field = if (inApp) findField(root!!, step) else null
            if (field != null) {
                val value = fill(run, step.text)
                field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = android.os.Bundle()
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
                val ok = field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                if (!ok) return endMacro(run, false, "Step $n: the app would not accept typed text.")
                EventLog.add(this, EV_SYSTEM, "Macro step $n", "Typed ${value.length} characters")
                return advance(run)
            }
            if (now - run.stepStart < step.waitSec * 1000L) { main.postDelayed(tick, 400); return }
            if (step.ifMissing == IF_SKIP) {
                EventLog.add(this, EV_SYSTEM, "Macro step $n", "Text field not found, skipped")
                return advance(run)
            }
            return endMacro(run, false, "Step $n: could not find the text field.")
        }

        val found = if (inApp) findStep(root!!, step) else null
        if (found != null) return doTap(run, step, found, "Tapped")
        if (now - run.stepStart < step.waitSec * 1000L) {
            main.postDelayed(tick, 400)
            return
        }
        // Not found in time: do what the step says.
        when (step.ifMissing) {
            IF_SKIP -> {
                EventLog.add(this, EV_SYSTEM, "Macro step $n", "'${step.label()}' not found, skipped")
                advance(run)
            }
            IF_FIRST -> {
                val first = if (inApp) firstLike(root!!, step) else null
                if (first != null) doTap(run, step, first, "Not found, tapped the first similar item:")
                else endMacro(run, false, "Step $n: nothing similar to '${step.label()}' on screen.")
            }
            IF_COORDS -> {
                EventLog.add(this, EV_SYSTEM, "Macro step $n", "'${step.label()}' not found, tapped the recorded spot")
                tapAt(step.x, step.y)
                advance(run)
            }
            IF_ALT -> {
                val alt = if (inApp && step.alt.isNotBlank()) findIn(root!!) { it.text?.toString()?.contains(step.alt, true) == true || it.contentDescription?.toString()?.contains(step.alt, true) == true } else null
                if (alt != null) doTap(run, step, alt, "Not found, tapped '${step.alt}':")
                else endMacro(run, false, "Step $n: could not find '${step.label()}' or '${step.alt}'.")
            }
            else -> endMacro(run, false, "Step $n: could not find '${step.label()}'.")
        }
    }

    private fun findField(root: AccessibilityNodeInfo, s: Step): AccessibilityNodeInfo? {
        if (s.viewId.isNotEmpty()) {
            val l = root.findAccessibilityNodeInfosByViewId(s.viewId)
            val hit = l?.firstOrNull { it.isEditable }
            if (hit != null) return hit
        }
        return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: findIn(root) { it.isEditable }
    }

    private fun doTap(run: Run, step: Step, node: AccessibilityNodeInfo, verb: String) {
        var target: AccessibilityNodeInfo? = node
        var done = false
        var hops = 0
        while (target != null && hops < 6 && !done) {
            if (target.isClickable) done = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            target = if (done) target else target.parent
            hops++
        }
        if (!done) {
            val b = Rect()
            node.getBoundsInScreen(b)
            tapAt(b.centerX(), b.centerY())
        }
        EventLog.add(this, EV_SYSTEM, "Macro step ${run.idx + 1}", "$verb '${node.text ?: node.contentDescription ?: step.label()}'")
        advance(run)
    }

    private fun advance(run: Run) {
        run.idx++
        run.stepStart = System.currentTimeMillis() + 900
        main.postDelayed(tick, 900)
    }

    private fun tapAt(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        dispatchGesture(g, null, null)
    }

    private fun findIn(n: AccessibilityNodeInfo, depth: Int = 0, test: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (depth > 30) return null
        if (test(n)) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val hit = findIn(c, depth + 1, test)
            if (hit != null) return hit
        }
        return null
    }

    private fun findStep(root: AccessibilityNodeInfo, s: Step): AccessibilityNodeInfo? {
        if (s.viewId.isNotEmpty()) {
            val l = root.findAccessibilityNodeInfosByViewId(s.viewId)
            if (!l.isNullOrEmpty()) {
                val hit = if (s.text.isEmpty()) l[0] else l.firstOrNull { it.text?.toString() == s.text }
                if (hit != null) return hit
            }
        }
        if (s.text.isNotEmpty()) {
            val hit = findIn(root) { it.text?.toString() == s.text }
            if (hit != null) return hit
        }
        if (s.desc.isNotEmpty()) return findIn(root) { it.contentDescription?.toString() == s.desc }
        return null
    }

    private fun firstLike(root: AccessibilityNodeInfo, s: Step): AccessibilityNodeInfo? =
        findIn(root) {
            it.isClickable && it.className?.toString() == s.cls && (s.viewId.isEmpty() || it.viewIdResourceName == s.viewId)
        }

    /** Called from the SMS thread. Returns null when queued, or the reason it was not. */
    fun submit(job: PhoneControl.Job): String? {
        val full = synchronized(queue) { queue.size >= MAX_QUEUE }
        if (full) return "Too many WhatsApp messages are waiting."
        main.post {
            queue.addLast(job)
            if (current == null) next()
        }
        return null
    }

    private fun next() {
        val job = if (queue.isEmpty()) return else queue.removeFirst()
        if (!PhoneControl.enabled(this)) {
            Forwarder.onAppResult(this, job, false, "Phone control is switched off in Settings.")
            next()
            return
        }
        current = job
        val uri = Uri.parse("https://wa.me/${job.number}?text=${Uri.encode(job.text.take(1500))}")
        var opened = false
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                opened = true
                break
            } catch (e: Exception) {
                // try the next WhatsApp package
            }
        }
        if (!opened) {
            finish(job, false, "Could not open WhatsApp. Is it installed?")
            return
        }
        val t = Runnable { finish(job, false, "WhatsApp did not show a Send button in time (is the number on WhatsApp?).") }
        timeout = t
        main.postDelayed(t, JOB_TIMEOUT_MS)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val rec = recording
        if (rec != null) {
            if (event?.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) capture(rec, event)
            if (event?.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) captureTyping(rec, event)
            return
        }
        if (running != null) return
        val job = current ?: return
        if (job.clicked) return
        val pkg = event?.packageName?.toString() ?: return
        if (!pkg.startsWith("com.whatsapp")) return
        if (!PhoneControl.enabled(this)) {
            finish(job, false, "Phone control was switched off.")
            return
        }
        val root = rootInActiveWindow ?: return
        val send = findSend(root) ?: return
        if (send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            job.clicked = true
            // Give WhatsApp a moment to hand the message over, then go back to the home screen.
            main.postDelayed({
                performGlobalAction(GLOBAL_ACTION_HOME)
                finish(job, true, "")
            }, 1200)
        }
    }

    private fun findSend(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            val hit = root.findAccessibilityNodeInfosByViewId(id)
            if (!hit.isNullOrEmpty()) return hit[0]
        }
        // Fallback: a clickable control whose label is exactly "Send".
        val byText = root.findAccessibilityNodeInfosByText("Send")
        return byText?.firstOrNull { it.isClickable && (it.contentDescription?.toString() == "Send" || it.text?.toString() == "Send") }
    }

    private fun finish(job: PhoneControl.Job, ok: Boolean, why: String) {
        if (current !== job) return
        timeout?.let { main.removeCallbacks(it) }
        timeout = null
        current = null
        Forwarder.onAppResult(this, job, ok, why)
        main.postDelayed({ next() }, 800)
    }
}
