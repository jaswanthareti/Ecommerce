package com.example.smssentinel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** The entry point: runs for every incoming SMS and applies the rules. */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs.isNullOrEmpty()) return
        val sender = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }

        // WhatsApp needs the network, which must not run on the main thread: keep the receiver alive and work in the background.
        val pending = goAsync()
        Thread {
            try {
                process(ctx, sender, body)
            } catch (e: Exception) {
                EventLog.add(ctx, EV_SYSTEM, "Error", e.message ?: e.javaClass.simpleName)
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun process(ctx: Context, sender: String, body: String) {
        val rules = RuleStore.load(ctx).filter { it.enabled }

        // 1) Stop running reminders whose "stop" condition matches this SMS.
        val stopped = HashSet<Int>()
        for (r in rules) {
            if (r.remind && Alerts.isReminding(ctx, r.id) && Matcher.stops(ctx, r, sender, body)) {
                Alerts.stopReminder(ctx, r.id, "stop message received")
                stopped.add(r.id)
            }
        }

        // 2) Run every rule that matches.
        for (r in rules) {
            if (r.id in stopped) continue
            if (Matcher.triggers(ctx, r, sender, body)) trigger(ctx, r, sender, body)
        }
    }

    private fun trigger(ctx: Context, r: Rule, sender: String, body: String) {
        if (!Matcher.inWindow(r)) {
            EventLog.add(ctx, EV_SYSTEM, r.name, "Matched, but outside the allowed time")
            return
        }
        if (!RuleStore.cooldownOk(ctx, r)) {
            EventLog.add(ctx, EV_SYSTEM, r.name, "Skipped (cooldown period)")
            return
        }
        val count = RuleStore.markTriggered(ctx, r)
        val text = "$sender: " + body.trim().take(300)

        if (r.remind) Alerts.startReminder(ctx, r)
        when {
            r.alarm -> {
                Alerts.post(ctx, r, text, KIND_ALARM)
                EventLog.add(ctx, EV_ALARM, r.name, text)
            }
            r.notify || r.remind -> {
                Alerts.post(ctx, r, text, KIND_ALERT)
                if (r.remind) EventLog.add(ctx, EV_REMINDER, r.name, "Reminders started: $text")
                else EventLog.add(ctx, EV_MATCHED, r.name, text)
            }
        }
        if (r.forward) Forwarder.forward(ctx, r, sender, body)
        if (r.macroId != 0) {
            val why = PhoneControl.runMacro(ctx, r.macroId, r.name, mapOf("sms" to body.trim(), "sender" to sender, "rule" to r.name))
            if (why != null) EventLog.add(ctx, EV_SYSTEM, r.name, "Macro not run: $why")
        }

        if (r.maxTriggers > 0 && count >= r.maxTriggers) {
            r.enabled = false
            RuleStore.upsert(ctx, r)
            Alerts.stopReminder(ctx, r.id, "rule reached its limit")
            EventLog.add(ctx, EV_SYSTEM, r.name, "Turned off after $count triggers")
        }
    }
}
