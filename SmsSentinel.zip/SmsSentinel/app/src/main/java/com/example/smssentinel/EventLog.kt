package com.example.smssentinel

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val EV_FORWARDED = "forwarded"
const val EV_ALARM = "alarm"
const val EV_REMINDER = "reminder"
const val EV_MATCHED = "matched"
const val EV_SYSTEM = "system"

data class Event(val time: Long, val type: String, val title: String, val detail: String)

/** Structured activity history (newest first, capped) plus all-time counters for the home screen. */
object EventLog {
    private const val KEY = "events"
    private const val MAX = 200

    fun add(ctx: Context, type: String, title: String, detail: String = "") {
        val p = RuleStore.prefs(ctx)
        val list = all(ctx).toMutableList()
        list.add(0, Event(System.currentTimeMillis(), type, title, detail))
        val arr = JSONArray()
        list.take(MAX).forEach {
            arr.put(JSONObject().put("t", it.time).put("y", it.type).put("n", it.title).put("d", it.detail))
        }
        val ed = p.edit().putString(KEY, arr.toString())
        val counter = when (type) {
            EV_FORWARDED -> "n_forwarded"
            EV_ALARM -> "n_alarms"
            EV_REMINDER -> "n_reminders"
            else -> null
        }
        if (counter != null) ed.putInt(counter, p.getInt(counter, 0) + 1)
        ed.apply()
    }

    fun all(ctx: Context): List<Event> {
        val s = RuleStore.prefs(ctx).getString(KEY, null) ?: return emptyList()
        val out = mutableListOf<Event>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Event(o.optLong("t"), o.optString("y"), o.optString("n"), o.optString("d")))
            }
        } catch (e: Exception) {
            // corrupt history: start fresh
        }
        return out
    }

    fun clear(ctx: Context) {
        RuleStore.prefs(ctx).edit().remove(KEY).apply()
    }

    fun count(ctx: Context, counter: String): Int = RuleStore.prefs(ctx).getInt(counter, 0)
}
