package com.example.smssentinel

import android.content.Context
import android.telephony.PhoneNumberUtils
import org.json.JSONObject
import java.util.Calendar

const val MATCH_ANY = 0
const val MATCH_KEYWORDS = 1
const val MATCH_EXACT = 2
const val MATCH_REGEX = 3

const val VIA_SMS = 0
const val VIA_APP = 2               // the normal WhatsApp app, driven by the Phone control service

data class Rule(
    var id: Int = 0,
    var name: String = "New rule",
    var description: String = "",
    var enabled: Boolean = true,
    // ---- trigger ----
    var sender: String = "",            // blank = any sender
    var matchType: Int = MATCH_KEYWORDS,
    var pattern: String = "",           // keywords (comma separated) / exact text / regex
    var caseSensitive: Boolean = false,
    var trimSpaces: Boolean = true,
    // ---- actions ----
    var notify: Boolean = true,
    var alarm: Boolean = false,
    var remind: Boolean = false,
    var intervalMin: Int = 60,
    var stopSender: String = "",        // reminder stops when an SMS matches these
    var stopPattern: String = "",
    var forward: Boolean = false,
    var forwardTo: String = "",
    var prefix: String = "",
    var forwardVia: Int = VIA_SMS,      // VIA_SMS or VIA_APP
    var waFallback: Boolean = true,     // if the WhatsApp app cannot send, send a normal SMS instead
    var macroId: Int = 0,               // recorded macro to run when this rule triggers (0 = none)
    // ---- settings ----
    var timeLimit: Boolean = false,     // run only between fromMin and toMin
    var fromMin: Int = 7 * 60,
    var toMin: Int = 23 * 60,
    var cooldownMin: Int = 0,           // ignore repeat triggers for this many minutes
    var maxTriggers: Int = 0            // disable after this many triggers (0 = never)
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("description", description).put("enabled", enabled)
        .put("sender", sender).put("matchType", matchType).put("pattern", pattern)
        .put("caseSensitive", caseSensitive).put("trimSpaces", trimSpaces)
        .put("notify", notify).put("alarm", alarm).put("remind", remind).put("intervalMin", intervalMin)
        .put("stopSender", stopSender).put("stopPattern", stopPattern)
        .put("forward", forward).put("forwardTo", forwardTo).put("prefix", prefix)
        .put("forwardVia", forwardVia).put("waFallback", waFallback).put("macroId", macroId)
        .put("timeLimit", timeLimit).put("fromMin", fromMin).put("toMin", toMin)
        .put("cooldownMin", cooldownMin).put("maxTriggers", maxTriggers)

    /** One-line description of the trigger, e.g. "When SMS from AD-LBA contains 'low balance'". */
    fun describe(): String {
        val from = if (sender.isBlank()) "" else " from ${sender.trim()}"
        return when (matchType) {
            MATCH_KEYWORDS -> "When SMS$from contains '${pattern.trim()}'"
            MATCH_EXACT -> "When SMS$from is exactly '${pattern.trim()}'"
            MATCH_REGEX -> "When SMS$from matches '${pattern.trim().take(40)}${if (pattern.trim().length > 40) "..." else ""}'"
            else -> "When any SMS$from arrives"
        }
    }

    /** Coloured chips for the rule card: label to colour. */
    fun chips(): List<Pair<String, Int>> {
        val out = mutableListOf<Pair<String, Int>>()
        if (alarm) out.add("Alarm" to BAD)
        if (remind) out.add("Reminder every ${fmtInterval(intervalMin)}" to PURPLE)
        if (forward) {
            if (forwardTo.isBlank()) out.add("Forward: add a number" to WARN) else out.add("Forward to ${forwardTo.trim()}" + (if (forwardVia == VIA_APP) " (WhatsApp app)" else "") to ACCENT)
        }
        if (macroId != 0) out.add("Automation" to PURPLE)
        if (notify && !alarm) out.add("Notification" to TEAL)
        return out
    }

    companion object {
        fun fromJson(o: JSONObject): Rule {
            // Older versions stored "content"/"regex"/"quiet"; keep those rules working.
            val legacy = !o.has("matchType")
            var matchType = o.optInt("matchType", MATCH_KEYWORDS)
            var pattern = o.optString("pattern", "")
            var timeLimit = o.optBoolean("timeLimit", false)
            if (legacy) {
                val c = o.optString("content", "")
                pattern = c
                matchType = if (c.isBlank()) MATCH_ANY else if (o.optBoolean("regex", false)) MATCH_REGEX else MATCH_KEYWORDS
                timeLimit = o.optBoolean("quiet", false)
            }
            return Rule(
                id = o.optInt("id"),
                name = o.optString("name", "Rule"),
                description = o.optString("description", ""),
                enabled = o.optBoolean("enabled", true),
                sender = o.optString("sender", ""),
                matchType = matchType,
                pattern = pattern,
                caseSensitive = o.optBoolean("caseSensitive", false),
                trimSpaces = o.optBoolean("trimSpaces", true),
                notify = o.optBoolean("notify", true),
                alarm = o.optBoolean("alarm", false),
                remind = o.optBoolean("remind", false),
                intervalMin = o.optInt("intervalMin", 60).coerceAtLeast(1),
                stopSender = o.optString("stopSender", ""),
                stopPattern = o.optString("stopPattern", o.optString("stopContent", "")),
                forward = o.optBoolean("forward", false),
                forwardTo = o.optString("forwardTo", ""),
                prefix = o.optString("prefix", ""),
                forwardVia = if (o.optInt("forwardVia", VIA_SMS) == VIA_APP) VIA_APP else VIA_SMS,  // old WhatsApp Business rules become SMS
                waFallback = o.optBoolean("waFallback", true),
                macroId = o.optInt("macroId", 0),
                timeLimit = timeLimit,
                fromMin = o.optInt("fromMin", 7 * 60),
                toMin = o.optInt("toMin", 23 * 60),
                cooldownMin = o.optInt("cooldownMin", 0).coerceAtLeast(0),
                maxTriggers = o.optInt("maxTriggers", 0).coerceAtLeast(0)
            )
        }
    }
}

fun fmtInterval(min: Int): String = when {
    min % 1440 == 0 -> if (min == 1440) "1 day" else "${min / 1440} days"
    min % 60 == 0 -> if (min == 60) "60 min" else "${min / 60} hours"
    else -> "$min min"
}

object Matcher {
    private fun digits(s: String) = s.filter { it.isDigit() }

    /** Blank pattern = any sender. A name (with letters) matches if the sender contains it. */
    fun senderMatches(ctx: Context, sender: String, pattern: String): Boolean {
        val p = pattern.trim()
        if (p.isEmpty()) return true
        if (p.any { it.isLetter() }) return sender.contains(p, ignoreCase = true)
        val dp = digits(p)
        return PhoneNumberUtils.compare(ctx, sender, p) || (dp.length >= 7 && digits(sender).endsWith(dp))
    }

    /** Does the SMS text satisfy the rule's text condition? */
    fun textMatches(r: Rule, body: String): Boolean {
        val text = if (r.trimSpaces) body.trim() else body
        val ignoreCase = !r.caseSensitive
        return when (r.matchType) {
            MATCH_ANY -> true
            MATCH_KEYWORDS -> {
                val words = r.pattern.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                words.isNotEmpty() && words.any { text.contains(it, ignoreCase = ignoreCase) }
            }
            MATCH_EXACT -> {
                val want = if (r.trimSpaces) r.pattern.trim() else r.pattern
                want.isNotEmpty() && text.equals(want, ignoreCase = ignoreCase)
            }
            MATCH_REGEX -> try {
                val opts = mutableSetOf(RegexOption.DOT_MATCHES_ALL)
                if (ignoreCase) opts.add(RegexOption.IGNORE_CASE)
                r.pattern.isNotBlank() && Regex(r.pattern, opts).containsMatchIn(text)
            } catch (e: Exception) {
                false
            }
            else -> false
        }
    }

    fun validRegex(p: String): Boolean = try { Regex(p); true } catch (e: Exception) { false }

    fun triggers(ctx: Context, r: Rule, sender: String, body: String): Boolean {
        // No sender and no text condition would match every SMS: never allow that.
        if (r.sender.isBlank() && r.matchType == MATCH_ANY) return false
        return senderMatches(ctx, sender, r.sender) && textMatches(r, body)
    }

    fun stops(ctx: Context, r: Rule, sender: String, body: String): Boolean {
        if (r.stopSender.isBlank() && r.stopPattern.isBlank()) return false
        val textOk = r.stopPattern.isBlank() || body.contains(r.stopPattern.trim(), ignoreCase = true)
        return senderMatches(ctx, sender, r.stopSender) && textOk
    }

    // ---- allowed time window ----

    private fun minuteOfDay(ms: Long): Int {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    private fun inside(r: Rule, minute: Int): Boolean {
        if (!r.timeLimit || r.fromMin == r.toMin) return true
        return if (r.fromMin < r.toMin) minute >= r.fromMin && minute < r.toMin
        else minute >= r.fromMin || minute < r.toMin   // window wraps past midnight
    }

    fun inWindow(r: Rule, now: Long = System.currentTimeMillis()): Boolean = inside(r, minuteOfDay(now))

    /** If [at] falls outside the rule's window, returns the next moment the window opens. */
    fun nextAllowed(r: Rule, at: Long): Long {
        if (inside(r, minuteOfDay(at))) return at
        val c = Calendar.getInstance().apply {
            timeInMillis = at
            set(Calendar.HOUR_OF_DAY, r.fromMin / 60)
            set(Calendar.MINUTE, r.fromMin % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= at) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }
}
