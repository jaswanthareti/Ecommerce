package com.example.smssentinel

import android.content.Context

object Numbers {
    private const val K_CC = "default_country_code"

    fun countryCode(ctx: Context): String = RuleStore.prefs(ctx).getString(K_CC, "91") ?: "91"

    /** Digits only, no leading zeros, with the default country code added to short local numbers. */
    fun toNumber(ctx: Context, raw: String): String {
        val digits = raw.filter { it.isDigit() }.trimStart('0')
        return if (digits.length <= 10) countryCode(ctx) + digits else digits
    }
}
