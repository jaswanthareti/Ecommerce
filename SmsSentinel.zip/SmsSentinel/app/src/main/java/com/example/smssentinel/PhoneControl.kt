package com.example.smssentinel

import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Context
import android.os.PowerManager
import android.provider.Settings

/**
 * Safety layer in front of the Phone control (accessibility) service.
 * A job is only accepted when ALL of these hold: the master switch is on, the service is running,
 * the phone is awake and unlocked, and the number is listed in one of your enabled forwarding rules.
 */
object PhoneControl {
    class Job(val rule: Rule, val sender: String, val to: String, val number: String, val text: String) {
        var clicked = false
    }

    private const val K_ENABLED = "ctl_enabled"

    fun enabled(ctx: Context): Boolean = RuleStore.prefs(ctx).getBoolean(K_ENABLED, true)
    fun setEnabled(ctx: Context, v: Boolean) = RuleStore.prefs(ctx).edit().putBoolean(K_ENABLED, v).apply()

    /** True when the service is switched on in Android's Accessibility settings. */
    fun serviceEnabled(ctx: Context): Boolean {
        val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return list.split(':').any {
            val c = ComponentName.unflattenFromString(it)
            c != null && c.packageName == ctx.packageName && c.className == ControlService::class.java.name
        }
    }

    /** Only numbers that appear in an enabled forwarding rule may ever be messaged. */
    fun isListed(ctx: Context, number: String): Boolean =
        RuleStore.load(ctx).any { it.enabled && it.forward && it.forwardTo.isNotBlank() && Numbers.toNumber(ctx, it.forwardTo) == number }

    private fun unlocked(ctx: Context): Boolean = ctx.service<PowerManager>().isInteractive && !ctx.service<KeyguardManager>().isKeyguardLocked

    /** Starts a recorded macro. Returns null when it was accepted (it runs on the main thread), otherwise the reason. */
    fun runMacro(ctx: Context, macroId: Int, ruleName: String, vars: Map<String, String> = emptyMap()): String? {
        if (!enabled(ctx)) return "Phone control is switched off in Settings."
        val svc = ControlService.instance ?: return "The Phone control service is not running."
        if (!unlocked(ctx)) return "The phone is locked or the screen is off."
        val m = MacroStore.get(ctx, macroId) ?: return "The macro no longer exists."
        if (m.steps.isEmpty()) return "The macro has no steps."
        svc.startMacro(m, ruleName, vars)
        return null
    }

    fun startRecording(ctx: Context, name: String): String? {
        if (!enabled(ctx)) return "Phone control is switched off in Settings."
        val svc = ControlService.instance ?: return "The Phone control service is not running. Turn it on in Settings."
        if (!unlocked(ctx)) return "Unlock the phone first."
        return svc.startRecording(name)
    }

    /** Returns null when the job was accepted, otherwise the reason it was refused. */
    fun submit(ctx: Context, r: Rule, sender: String, to: String, text: String): String? {
        if (!enabled(ctx)) return "Phone control is switched off in Settings."
        val svc = ControlService.instance ?: return "The Phone control service is not running. Turn it on in Settings."
        val pm = ctx.service<PowerManager>()
        val km = ctx.service<KeyguardManager>()
        if (!pm.isInteractive || km.isKeyguardLocked) return "The phone is locked or the screen is off."
        val number = Numbers.toNumber(ctx, to)
        if (number.length < 8) return "The number looks too short."
        if (!isListed(ctx, number)) return "That number is not in any enabled forwarding rule."
        return svc.submit(PhoneControl.Job(r, sender, to, number, text))
    }
}
