package com.example.smssentinel

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

val FIELD: Int = Color.parseColor("#0E1727")

/** A single-line (or multi-line) text box that reports every change. */
fun input(
    ctx: Context,
    hintText: String,
    value: String,
    type: Int = InputType.TYPE_CLASS_TEXT,
    lines: Int = 1,
    onChange: (String) -> Unit
): EditText = EditText(ctx).apply {
    inputType = if (lines > 1) type or InputType.TYPE_TEXT_FLAG_MULTI_LINE else type
    setHint(hintText)
    setText(value)
    setTextColor(INK)
    setHintTextColor(MUTED)
    setTextSize(16f)
    if (lines > 1) {
        setMinLines(lines)
        gravity = Gravity.TOP or Gravity.START
    } else {
        setSingleLine(true)
    }
    background = rounded(ctx, FIELD, 12, LINE)
    setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) {
            onChange(s?.toString() ?: "")
        }
    })
}

/** A Material-style on/off switch in the app colours. */
fun switchView(ctx: Context, checked: Boolean, onChange: (Boolean) -> Unit): Switch = Switch(ctx).apply {
    isChecked = checked
    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, MUTED))
    trackTintList = ColorStateList(states, intArrayOf(PRIMARY_A, LINE))
    setOnCheckedChangeListener { _, v -> onChange(v) }
}

/** Small label above a field. */
fun fieldLabel(ctx: Context, s: String): TextView =
    text(ctx, s, 13f, MUTED, true).apply { setPadding(ctx.dp(2), 0, 0, ctx.dp(6)) }

/** Muted explanation text under a field. */
fun note(ctx: Context, s: String): TextView =
    text(ctx, s, 12f, MUTED).apply { setPadding(ctx.dp(2), ctx.dp(6), ctx.dp(2), 0) }

fun divider(ctx: Context): View = View(ctx).apply {
    setBackgroundColor(LINE)
    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
}

/** Icon tile + title + optional subtitle + optional trailing view (switch, button, check). */
fun settingRow(
    ctx: Context,
    icon: Int,
    color: Int,
    title: String,
    sub: String = "",
    trailing: View? = null,
    onClick: (() -> Unit)? = null
): LinearLayout = row(ctx).apply {
    setPadding(0, ctx.dp(8), 0, ctx.dp(8))
    addView(iconTile(ctx, icon, color, 40, 20))
    val col = column(ctx)
    col.addView(text(ctx, title, 15f, INK, true))
    if (sub.isNotEmpty()) col.addView(text(ctx, sub, 13f, MUTED))
    putH(col, 1f, 12)
    if (trailing != null) putH(trailing, 0f, 8)
    if (onClick != null) setOnClickListener { onClick() }
}

/**
 * Chips where exactly one is selected. Repaints itself in place, so the screen does not
 * have to be rebuilt (and the keyboard stays where it is).
 */
fun choiceRow(ctx: Context, labels: List<String>, selected: Int, onSelect: (Int) -> Unit): HorizontalScrollView {
    val r = row(ctx)
    val views = mutableListOf<TextView>()
    fun paint(sel: Int) {
        views.forEachIndexed { i, v ->
            val on = i == sel
            v.setTextColor(if (on) ACCENT else MUTED)
            v.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
            v.background = rounded(ctx, if (on) tint(ACCENT, 0.2f) else CARD, 18, if (on) ACCENT else LINE)
            v.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
        }
    }
    labels.forEachIndexed { i, label ->
        val c = text(ctx, label, 13f, MUTED, false).apply {
            setOnClickListener {
                paint(i)
                onSelect(i)
            }
        }
        views.add(c)
        r.putH(c, 0f, if (i == 0) 0 else 8)
    }
    paint(selected)
    return HorizontalScrollView(ctx).apply {
        setHorizontalScrollBarEnabled(false)
        addView(r)
    }
}

/** A 44dp tappable icon (close, back, more). */
fun iconButton(ctx: Context, res: Int, color: Int = INK, onClick: () -> Unit): LinearLayout =
    LinearLayout(ctx).apply {
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44))
        addView(iconView(ctx, res, 22, color))
        setOnClickListener { onClick() }
    }

/** A small rounded text button (Allow, Test, Done). */
fun pill(ctx: Context, label: String, color: Int = ACCENT, onClick: () -> Unit): TextView =
    text(ctx, label, 13f, color, true).apply {
        background = rounded(ctx, tint(color, 0.18f), 16)
        setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
        setOnClickListener { onClick() }
    }
