package com.example.smssentinel

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val IF_STOP = 0    // stop the macro
const val IF_SKIP = 1    // skip this step and carry on
const val IF_FIRST = 2   // tap the first similar item (same kind of control) on screen
const val IF_COORDS = 3  // tap the spot you tapped when recording
const val IF_ALT = 4     // tap something showing the "alternative text"

const val K_TAP = 0     // tap a control
const val K_TYPE = 1    // type text into a field; {sms}, {sender} and {rule} are replaced
const val K_WAIT = 2    // pause
const val K_BACK = 3    // Back button
const val K_HOME = 4    // Home button
const val K_SCROLL = 5  // scroll the first scrollable list forward
const val K_OPEN = 6    // open an app

/** One step: a recorded tap, or a step you added (type, wait, back, home, scroll, open app). Only what is needed to find the control again is stored; typed text and password fields are never recorded. */
class Step(
    val pkg: String,
    val viewId: String,
    var text: String,
    val desc: String,
    val cls: String,
    val x: Int,
    val y: Int,
    var ifMissing: Int = IF_STOP,
    var alt: String = "",
    var waitSec: Int = 6,
    var kind: Int = K_TAP
) {
    fun title(): String = when (kind) {
        K_TYPE -> "Type text"
        K_WAIT -> "Wait $waitSec seconds"
        K_BACK -> "Press Back"
        K_HOME -> "Press Home"
        K_SCROLL -> "Scroll down"
        K_OPEN -> "Open ${text.ifBlank { pkg }}"
        else -> "Tap '${label()}'"
    }

    fun label(): String = when {
        text.isNotBlank() -> text
        desc.isNotBlank() -> desc
        viewId.isNotBlank() -> viewId.substringAfter('/')
        else -> "position $x,$y"
    }

    fun toJson(): JSONObject = JSONObject().put("pkg", pkg).put("viewId", viewId).put("text", text).put("desc", desc)
        .put("cls", cls).put("x", x).put("y", y).put("ifMissing", ifMissing).put("alt", alt).put("waitSec", waitSec).put("kind", kind)

    companion object {
        fun fromJson(o: JSONObject) = Step(
            o.optString("pkg"), o.optString("viewId"), o.optString("text"), o.optString("desc"), o.optString("cls"),
            o.optInt("x"), o.optInt("y"), o.optInt("ifMissing", IF_STOP), o.optString("alt"), o.optInt("waitSec", 6).coerceIn(1, 60), o.optInt("kind", K_TAP)
        )
    }
}

class Macro(var id: Int, var name: String, val steps: MutableList<Step> = mutableListOf()) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name)
        .put("steps", JSONArray().also { a -> steps.forEach { a.put(it.toJson()) } })
}

object MacroStore {
    const val MAX_STEPS = 40

    fun load(ctx: Context): MutableList<Macro> {
        val out = mutableListOf<Macro>()
        try {
            val arr = JSONArray(RuleStore.prefs(ctx).getString("macros", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val m = Macro(o.optInt("id"), o.optString("name", "Macro"))
                val st = o.optJSONArray("steps")
                if (st != null) for (j in 0 until st.length()) m.steps.add(Step.fromJson(st.getJSONObject(j)))
                out.add(m)
            }
        } catch (e: Exception) {
            // unreadable data: start with an empty list
        }
        return out
    }

    fun get(ctx: Context, id: Int): Macro? = load(ctx).firstOrNull { it.id == id }

    fun upsert(ctx: Context, m: Macro) {
        val all = load(ctx)
        if (m.id == 0) m.id = (all.maxOfOrNull { it.id } ?: 0) + 1
        val i = all.indexOfFirst { it.id == m.id }
        if (i >= 0) all[i] = m else all.add(m)
        save(ctx, all)
    }

    fun delete(ctx: Context, id: Int) = save(ctx, load(ctx).filter { it.id != id })

    private fun save(ctx: Context, all: List<Macro>) {
        val arr = JSONArray()
        all.forEach { arr.put(it.toJson()) }
        RuleStore.prefs(ctx).edit().putString("macros", arr.toString()).apply()
    }
}
