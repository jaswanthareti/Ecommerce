package com.example.smssentinel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** The "Stop recording" button in the recording notification. */
class RecordStopReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        ControlService.instance?.stopRecording()
    }
}
