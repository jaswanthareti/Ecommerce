package com.example.smssentinel

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.window.OnBackInvokedDispatcher

/** Hosts the four tabs (Home, Rules, Activity, Settings) and the bottom navigation bar. */
class MainActivity : Activity() {
    companion object {
        const val EXTRA_TAB = "tab"
        const val TAB_HOME = 0
        const val TAB_RULES = 1
        const val TAB_ACTIVITY = 2
        const val TAB_SETTINGS = 3
        private const val REQ_PERMS = 1
    }

    private var tab = TAB_HOME
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout

    /** Selected filter chip on the Activity tab (0 = All). */
    var activityFilter = 0

    private val tabIcons = intArrayOf(R.drawable.ic_home, R.drawable.ic_bolt, R.drawable.ic_pulse, R.drawable.ic_settings)
    private val tabNames = arrayOf("Home", "Rules", "Activity", "Settings")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tab = savedInstanceState?.getInt(EXTRA_TAB, TAB_HOME) ?: intent.getIntExtra(EXTRA_TAB, TAB_HOME)

        val root = column(this)
        root.setBackgroundColor(BG)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val line = View(this)
        line.setBackgroundColor(LINE)
        root.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
        nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setPadding(dp(8), dp(6), dp(8), dp(6))
        root.addView(nav, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        setContentView(root)
        applyInsets(root)

        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) { goBack() }
        }
    }

    override fun onResume() {
        super.onResume()
        render(true)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(EXTRA_TAB, tab)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        tab = intent.getIntExtra(EXTRA_TAB, tab)
        render(false)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        goBack()
    }

    /** Back from any tab returns to Home first, then leaves the app. */
    private fun goBack() {
        if (tab != TAB_HOME) go(TAB_HOME) else finish()
    }

    // ---------------------------------------------------------------- navigation

    fun go(i: Int) {
        tab = i
        render(false)
    }

    /** Rebuilds the current tab, keeping the scroll position. */
    fun refresh() = render(true)

    private fun render(keepScroll: Boolean) {
        val old = scrollOf(content.getChildAt(0))?.scrollY ?: 0
        content.removeAllViews()
        val v: View = when (tab) {
            TAB_HOME -> homeScreen()
            TAB_RULES -> rulesScreen()
            TAB_ACTIVITY -> activityScreen()
            else -> settingsScreen()
        }
        content.addView(v)
        val sv = scrollOf(v)
        if (keepScroll && sv != null) sv.post { sv.scrollTo(0, old) }
        renderNav()
    }

    /** The ScrollView of a screen, whether it is the screen itself or the first child of a wrapper. */
    private fun scrollOf(v: View?): ScrollView? = when {
        v is ScrollView -> v
        v is ViewGroup && v.childCount > 0 -> scrollOf(v.getChildAt(0))
        else -> null
    }

    private fun renderNav() {
        nav.removeAllViews()
        for (i in tabNames.indices) {
            val on = i == tab
            val color = if (on) ACCENT else MUTED
            val holder = LinearLayout(this)
            holder.gravity = Gravity.CENTER
            holder.background = rounded(this, if (on) tint(ACCENT, 0.16f) else 0, 16)
            holder.setPadding(dp(18), dp(4), dp(18), dp(4))
            holder.addView(iconView(this, tabIcons[i], 22, color))

            // Icon pill and label are both wrap-sized and centred, so the label sits under its icon.
            val label = text(this, tabNames[i], 11f, color, on)
            label.gravity = Gravity.CENTER
            val item = column(this)
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(0, dp(2), 0, dp(2))
            item.addView(holder, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            item.addView(
                label,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(2) }
            )
            item.setOnClickListener { go(i) }
            nav.addView(item, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    fun openWizard(ruleId: Int = 0) {
        startActivity(Intent(this, RuleWizardActivity::class.java).putExtra(RuleWizardActivity.EXTRA_ID, ruleId))
    }

    // ---------------------------------------------------------------- permissions and system settings

    /** Asks for SMS (receive + send) and notification permission in one go. */
    fun requestCore() {
        val missing = mutableListOf<String>()
        if (!Perms.smsReceive(this)) missing.add(Manifest.permission.RECEIVE_SMS)
        if (!Perms.smsSend(this)) missing.add(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (missing.isEmpty()) {
            if (!Perms.notifications(this)) openNotificationSettings()
            else toast(this, "All permissions are already allowed")
            return
        }
        requestPermissions(missing.toTypedArray(), REQ_PERMS)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render(true)
    }

    fun openAppSettings() =
        startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))

    fun openNotificationSettings() =
        startSafely(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))

    fun openFullScreenSettings() {
        if (Build.VERSION.SDK_INT >= 34) {
            startSafely(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
        }
    }

    fun openAccessibilitySettings() = startSafely(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    fun openBatterySettings() = startSafely(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))

    private fun startSafely(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (e2: Exception) {
                toast(this, "Could not open settings. Open Settings > Apps > Guardly manually.")
            }
        }
    }
}

// ---------------------------------------------------------------- shared page helpers

fun toast(ctx: Context, s: String) {
    Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
}

fun confirm(ctx: Context, title: String, message: String, yes: String, onYes: () -> Unit) {
    AlertDialog.Builder(ctx)
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton(yes) { _, _ -> onYes() }
        .setNegativeButton("Cancel", null)
        .show()
}

/** Vertical page column with the standard screen padding. */
fun page(ctx: Context): LinearLayout = column(ctx).apply {
    setPadding(ctx.dp(20), ctx.dp(18), ctx.dp(20), ctx.dp(28))
}

fun scrolled(ctx: Context, content: View): ScrollView = ScrollView(ctx).apply {
    isVerticalScrollBarEnabled = false
    addView(content)
}

/** Big screen title with an optional subtitle and a trailing view (add button, clear...). */
fun screenHeader(ctx: Context, title: String, sub: String, trailing: View? = null): LinearLayout =
    row(ctx).apply {
        val col = column(ctx)
        col.addView(text(ctx, title, 26f, INK, true))
        if (sub.isNotEmpty()) col.addView(text(ctx, sub, 14f, MUTED))
        putH(col, 1f)
        if (trailing != null) putH(trailing, 0f, 12)
    }

/** Section title with an optional action link on the right ("See all"). */
fun sectionHeader(ctx: Context, title: String, action: String? = null, onAction: () -> Unit = {}): LinearLayout =
    row(ctx).apply {
        setPadding(ctx.dp(2), ctx.dp(22), ctx.dp(2), ctx.dp(8))
        putH(text(ctx, title, 18f, INK, true), 1f)
        if (action != null) {
            val a: TextView = text(ctx, action, 14f, ACCENT, true)
            a.setOnClickListener { onAction() }
            putH(a, 0f, 8)
        }
    }

/** Floating "+ label" button. Place it in a FrameLayout over the scrolling content so it stays on screen. */
fun floatingButton(ctx: Context, label: String, onClick: () -> Unit): LinearLayout = row(ctx).apply {
    background = gradient(ctx, PRIMARY_A, PRIMARY_B, 28)
    setPadding(ctx.dp(18), ctx.dp(14), ctx.dp(22), ctx.dp(14))
    elevation = ctx.dp(8).toFloat()
    addView(iconView(ctx, R.drawable.ic_add, 22, android.graphics.Color.WHITE))
    putH(text(ctx, label, 16f, android.graphics.Color.WHITE, true), 0f, 8)
    setOnClickListener { onClick() }
}

/** Picture, message and an optional button, for empty lists. */
fun emptyState(ctx: Context, title: String, message: String, action: String? = null, onAction: () -> Unit = {}): LinearLayout =
    column(ctx).apply {
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, ctx.dp(16), 0, ctx.dp(8))
        addView(roundedImage(ctx, R.drawable.art_empty, 24), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ctx.dp(190)))
        put(text(ctx, title, 18f, INK, true).apply { gravity = Gravity.CENTER }, top = 16)
        put(text(ctx, message, 14f, MUTED).apply { gravity = Gravity.CENTER }, top = 4)
        if (action != null) put(button(ctx, action, Btn.PRIMARY) { onAction() }, top = 16)
    }
